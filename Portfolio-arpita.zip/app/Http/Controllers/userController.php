<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Http\Request;

class userController extends Controller
{
    public function userlogin()
    {
        return view('user.userLogin');
    }
    public function userProfile($id){
        $users = User::find($id);
        return view('user.user',compact('users'));

    }
    public function userauthenticate(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            return redirect()->route('user.profile')->with('success', 'Login Success');
        }
        
        return redirect()->back()->withInput()->withErrors(['email' => 'Invalid credentials']);
    }
}
