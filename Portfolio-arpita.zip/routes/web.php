<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\userController;
use App\Http\Controllers\FrontControllr;

Route::prefix('admin')->group(function () {
    Route::get('login', [HomeController::class, 'login'])->name('login');
    Route::post('/login', [HomeController::class, 'authenticate']);
    Route::get('/index',[HomeController::class,'show'])->name('home.index');
    Route::get('/create', [HomeController::class, 'create'])->name('home.create');
    Route::get('/edit/{id}', [HomeController::class, 'edit'])->name('home.edit');
    Route::delete('delete',[HomeController::class,'destory'])->name('delete');

   
});
Route::get('userlogin', [userController::class, 'userlogin'])->name('userlogin');
Route::get('/user/{id}', [userController::class,'userProfile'])->name('user.profile');
Route::get('/userLogin', [userController::class,'userauthenticate'])->name('user.authinticate');
Route::get('index',[FrontControllr::class, 'front'])->name('index');

