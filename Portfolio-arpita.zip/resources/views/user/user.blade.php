<link rel="stylesheet" href="<?php echo asset(
        "home/index.css"
    ); ?>" type="text/css">

<main>
@include('layouts.sidebar')
@include('layouts.nav')
    <h1>Welcome {{ $users->name }}</h1>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td>{{$users->name }}</td>
                    <td>{{ $users->name }}</td>
                    </td>
                </tr>
        </tbody>
    </table>
</main>
