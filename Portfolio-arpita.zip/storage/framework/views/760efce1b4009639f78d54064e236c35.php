<link rel="stylesheet" href="<?php echo asset(
        "home/index.css"
    ); ?>" type="text/css">

<main>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Welcome <?php echo e($users->name); ?></h1>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td><?php echo e($users->name); ?></td>
                    <td><?php echo e($users->name); ?></td>
                    </td>
                </tr>
        </tbody>
    </table>
</main>
<?php /**PATH E:\ARPITA\Portfolio-apurba\resources\views/user/user.blade.php ENDPATH**/ ?>